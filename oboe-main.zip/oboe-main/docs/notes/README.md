[Oboe Docs Home](https://github.com/google/oboe/blob/main/docs/README.md)

Note that the Tech Notes are moving to here: https://github.com/google/oboe/wiki#tech-notes

# Oboe Tech Notes

* [Buffer Terminology - Frames, Capacity, Size, Burst](https://github.com/google/oboe/wiki/TechNote_BufferTerminology)
* [Using Audio Effects with Oboe](effects.md)
* [Disconnected Streams](disconnect.md) - Responding to Plugging In and Unplugging Headsets
* [Assert in releaseBuffer()](rlsbuffer.md)
* [Glitches and Latency](https://github.com/google/oboe/wiki/TechNote_Glitches)
